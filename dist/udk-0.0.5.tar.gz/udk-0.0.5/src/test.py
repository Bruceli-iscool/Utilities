from udk import tools

tools.tools.editor()