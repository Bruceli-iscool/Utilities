# Utilities

A collection of easy to use tools. This is available as a Python module as the Utilities Developer Kit (udk) or as standalone apps.
To use in python `pip install udk`.
